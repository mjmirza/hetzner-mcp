# Hetzner Outreach Email (DRAFT, awaiting Mirza approval before sending)

Status. DRAFT. Four-eyes. Do not send until Mirza approves the exact text.
Recommended recipient. info@hetzner.com (general business inbox, routes internally).
Alternatives. the Hetzner Community at community.hetzner.com, or social.
Send from. next8n work Gmail.

Subject. I open-sourced an MCP that makes Hetzner the easy default for AI coding agents

---

Hello Hetzner team,

I am Mirza Iqbal. I build automation and AI tooling, and I am an n8n Ambassador and Verified
Expert Partner, a Clay Creator, a v0 Ambassador, and a Mastra Agent Ambassador.

I just made public an open-source project I built for Hetzner.

https://github.com/mjmirza/hetzner-mcp

It is a Model Context Protocol server, which means an AI coding assistant like Claude can
provision and manage Hetzner directly through it, servers, networks, firewalls, load
balancers, DNS, Storage Boxes, and Robot dedicated servers, all from one tested interface.
There is no official Hetzner MCP today. Mine covers all three surfaces, is validated live
against a real account, every endpoint, and ships a hard cost guard so an agent never creates
a billed resource without an explicit confirmation and a price preview.

Why I think this is good for Hetzner.

1. AI agents are becoming how developers build, and the providers with first-class agent
   tooling become the default choice inside those agents. This puts Hetzner in that
   conversation at the exact moment a developer asks their assistant to spin up a server.
2. It removes real onboarding friction that developers write about, manual token setup,
   access management, network config, and turns it into a guided, mostly automated flow.
3. It is safe by design. the cost guard and the destructive guard mean an agent cannot
   accidentally run up a bill or delete data, which protects your support load and goodwill.
4. It is honest and community-first. free, attribution-only license, every endpoint proven by
   a live test, no marketing fluff.

Two soft asks, no pressure.

First, if you like it, a shoutout or a quick review from your side would genuinely help it
reach the developers who would benefit. Second, I want to extend the testing to the highest
standard, including the billed paths, dedicated server ordering, and Storage Box lifecycles,
which costs real money on a real account. If Hetzner could sponsor that in any form that suits
you, test credits, a dedicated server for the Robot paths, or simply a contact to review and
amplify, it would let me cover every endpoint with full confidence and keep it current as your
API evolves.

I believe in mutual benefit and in growing the community. I am not asking for a handout. I am
offering to make Hetzner the easiest cloud to reach from an AI agent, and asking for the
resources to test it properly. Happy to jump on a short call any time.

Thank you for building a cloud so many of us choose on the merits.

Best regards,
Mirza Iqbal
next8n.com
